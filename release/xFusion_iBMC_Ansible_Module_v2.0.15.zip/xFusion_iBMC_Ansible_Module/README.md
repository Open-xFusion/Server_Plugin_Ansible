****************************************************************************
Ansible Plugin Package for xFusion Device
****************************************************************************

I. General Information

    Name:     Ansible Plugin Pack for xFusion Server
    Function: Query, Configuration, Deployment, and Upgrade
    Version:  2.0.16

	
II. Description

    Integrated in the Ansible software, xFusion Ansible plug-in is used to manage xFusion servers and connects to the iBMC through the Redfish interface. 
    With this plug-in, you can query, configure, deploy, and upgrade the xFusion server.

	
III.Supported Software Version

    Ansible: 2.5.0 or later	

	
IV. Software Prerequisites

    python: 2.7 or later, 3.7 or later
    python requests: 2.6.0 or later
    python requests_toolbelt: 0.9.1 later
    jq: 1.5 or later
    sshpass: 1.06 or later
	
	
V. Supported Device
    
    X86 Architecture:
        Blade server: CH121 V3, CH121 V5, CH121L V5, CH242 V3, CH242 V5, MM921, CX621, CX320
        Rack server: RH2288H V3, 2288H V5, 2488 V5, 1288H V6, 2288H V6, 5288 V6, 1288H V7, 2288H V7, 5288 V7, 1258H V7, 2288 V7, 5885H V7, 2158H V8, 2258H V8, 2288 V8
        High-density server: XH622 V3, XH321 V5
        AI server: G560 V5, G6550 V8

	
VI. Additional Resources

    For more information consult User Guide. go to the xFusion github repository.
