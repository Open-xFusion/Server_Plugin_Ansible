#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright (C) 2019-2021 xFusion Digital Technologies Co., Ltd. All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v3.0+

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License v3.0+ for more detail

ANSIBLE_METADATA = {
    'metadata_version': '1.1',
    'status': ['preview'],
    'supported_by': 'community'
}

DOCUMENTATION = r'''
---
module: ibmc_create_account
short_description: Create an ibmc user
version_added: "2.5.0"
description:
    - Create an ibmc user
options:
    ibmc_ip:
        required: true
        default: None
        description:
            - iBMC IP address
    ibmc_user:
        required: true
        default: None
        description:
            - iBMC user name used for authentication
    ibmc_pswd:
        required: true
        default: None
        description:
            - iBMC user password used for authentication
    new_account_user:
        required: true
        default: None
        description:
            - New user name
    new_account_pswd:
        required: true
        default: None
        description:
            - New password
    roleid:
        required: true
        default: None
        description:
            - User Role
        choices: [ Administrator, Operator, Commonuser, Noaccess, CustomRole1, CustomRole2, CustomRole3, CustomRole4 ]
'''

EXAMPLES = r'''
- name: create ibmc account
  ibmc_create_account:
    ibmc_ip: "{{ ibmc_ip }}"
    ibmc_user: "{{ ibmc_user }}"
    ibmc_pswd: "{{ ibmc_pswd }}"
    new_account_user: "{{ account_user }}"
    new_account_pswd: "{{ account_pswd }}"
    roleid: "Administrator"

'''

RETURNS = r'''
    "msg": "The account is created successfully!"
'''

from ansible.module_utils.basic import AnsibleModule

from ibmc_ansible.ibmc_logger import log
from ibmc_ansible.ibmc_logger import report
from ibmc_ansible.ibmc_redfish_api.api_manage_account import create_account
from ibmc_ansible.ibmc_redfish_api.redfish_base import IbmcBaseConnect
from ibmc_ansible.utils import REQUIRED, TYPE, STR, NO_LOG
from ibmc_ansible.utils import ansible_ibmc_run_module


def ibmc_create_account_module(module):
    """
    Function:

    Args:
              ansible_module       (class):

    Returns:
        "result": False
        "msg": 'not run create account yet'
    Raises:
        Exception
    Examples:

    Author: xwh
    Date: 2019/10/9 20:30
    """
    ret = {"result": False, "msg": 'not run create account yet'}

    with IbmcBaseConnect(module.params, log, report) as ibmc:
        ret = create_account(ibmc, module.params["new_account_user"], module.params["new_account_pswd"],
                             module.params["roleid"])
    return ret


def main():
    module = AnsibleModule(
        argument_spec={
            "ibmc_ip": {REQUIRED: True, TYPE: STR},
            "ibmc_user": {REQUIRED: True, TYPE: STR},
            "ibmc_pswd": {REQUIRED: True, TYPE: STR, NO_LOG: True},
            "new_account_user": {REQUIRED: True, TYPE: STR},
            "new_account_pswd": {REQUIRED: True, TYPE: STR, NO_LOG: True},
            "roleid": {REQUIRED: True, TYPE: STR},
        },
        supports_check_mode=False)
    ansible_ibmc_run_module(ibmc_create_account_module, module, log, report)


if __name__ == '__main__':
    main()
