#!/usr/bin/python
# -*- coding: UTF-8 -*-

# Copyright (C) 2019-2021 xFusion Digital Technologies Co., Ltd. All rights reserved.
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License v3.0+

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License v3.0+ for more detail

import time

from ibmc_ansible.ibmc_redfish_api.api_inband_fw_update import sp_api_set_sp_service
from ibmc_ansible.ibmc_redfish_api.api_inband_fw_update import sp_api_get_status
from ibmc_ansible.ibmc_redfish_api.api_inband_fw_update import SP_STATUS_WORKING
from ibmc_ansible.ibmc_redfish_api.api_inband_fw_update import WAIT_SP_START_TIME
from ibmc_ansible.ibmc_redfish_api.api_inband_fw_update import CHECK_INTERVAL
from ibmc_ansible.ibmc_redfish_api.api_power_manager import manage_power

from ibmc_ansible.utils import set_result
from ibmc_ansible.utils import RESULT, MSG

BMC_EXPECT_VERSION = "3.20"
SP_EXPECT_VERSION = "1.09"
SP_STATUS = "sp_status"
OS_PROGRESS = "os_progress"
OS_STATUS = "os_status"
OS_STEP = "os_step"
OS_ERROR_INFO = "os_error_info"
OS_INSTALL = "OSInstall"
RESULTS = "Results"


def config_os(ibmc, os_config):
    """
     Function:
         config the os you want to deploy
     Args:
          ibmc:   IbmcBaseConnect Object
          os_config   (dict):
     Returns:

     Raises:
         Exception
     Examples:
         None
     Author:
     Date: 10/26/2019
    """
    ret = {RESULT: True, MSG: ''}
    content = os_config
    # send restful request
    token = ibmc.get_token()
    # get interface id
    uri = "%s/SPService/SPOSInstallPara" % ibmc.manager_uri
    headers = {'content-type': 'application/json', 'X-Auth-Token': token}
    try:
        r = ibmc.request('POST', resource=uri,
                         headers=headers, data=content, tmout=10)
        result = r.status_code
        if result == 201:
            log_msg = "post os config parament successfully"
            set_result(ibmc.log_info, log_msg, True, ret)
        else:
            if result == 500 or result == 400:
                log_msg = "post os config parament failed! error json:%s" % str(
                    r.json())
                set_result(ibmc.log_error, log_msg, False, ret)
            else:
                log_msg = "post os config parament failed! error code:%s" % str(
                    result)
                set_result(ibmc.log_error, log_msg, False, ret)
    except Exception as e:
        ibmc.log_error("post os config parament failed! %s" % str(e))
        raise
    return ret


def set_sp_finished(ibmc):
    """
     Function:
         set sp finished
     Args:
          ibmc (str):   IbmcBaseConnect Object
     Returns:
        ret {}
     Raises:
         Exception
     Examples:
         None
     Author:
     Date: 10/26/2019
    """
    uri = "%s/SPService" % ibmc.manager_uri
    etag = ibmc.get_etag(uri)
    token = ibmc.get_token()
    headers = {'content-type': 'application/json', 'X-Auth-Token': token, 'If-Match': etag}
    payload = {"SPFinished": True}

    ret = {RESULT: True, MSG: ''}
    try:
        r = ibmc.request('PATCH', resource=uri,
                         headers=headers, data=payload, tmout=10)
        result = r.status_code
        if result == 200:
            log_msg = "set SP result finished successful! response is : %s" % str(
                r.json())
            set_result(ibmc.log_info, log_msg, True, ret)
        else:
            log_msg = "set SP result finished failed! error code is: %s" % str(
                result)
            set_result(ibmc.log_error, log_msg, False, ret)
    except Exception as e:
        ibmc.log_error(
            "set SP result finished failed! exception is: %s" % str(e))
        raise
    return ret


def vmm_is_connected(ibmc):
    """
     Function:
        check vmm if connected
     Args:
          ibmc (str):   IbmcBaseConnect Object
     Returns:
        ret {}
     Raises:
         Exception
     Examples:
         None
     Author:
     Date: 10/26/2019
    """
    result = ''
    token = ibmc.get_token()
    headers = {'content-type': 'application/json', 'X-Auth-Token': token}
    uri = "%s/VirtualMedia/CD" % ibmc.manager_uri
    payload = {}
    try:
        ret = ibmc.request('GET', resource=uri,
                           headers=headers, data=payload, tmout=30)
        if ret.status_code == 200:
            data = ret.json()
            result = data.get(u'Inserted')
        else:
            ibmc.log_error("get vmm info failed!")
            result = 'unknown'
    except Exception as e:
        ibmc.log_error(
            "check vmm connected exception! exception is:%s" % str(e))
    return result


def unmount_file(ibmc):
    """
     Function:
         unmount file from virtual cd
     Args:
          ibmc:   IbmcBaseConnect Object
     Returns:
        ret {}
     Raises:
         Exception
     Examples:
         None
     Author:
     Date: 10/26/2019
    """
    token = ibmc.get_token()
    oem_info = ibmc.oem_info
    headers = {'content-type': 'application/json', 'X-Auth-Token': token}
    uri = "%s/VirtualMedia/CD/Oem/%s/Actions/VirtualMedia.VmmControl" % (ibmc.manager_uri, oem_info)
    payload = {'VmmControlType': 'Disconnect'}
    try:
        r = ibmc.request('POST', resource=uri,
                         headers=headers, data=payload, tmout=30)
        result = r.status_code
        if result == 202:
            ibmc.log_info('unmount successful')
            time.sleep(10)
        elif result == 404:
            ibmc.log_info('unmount Failure:resource was not found')
        elif result == 400:
            ibmc.log_info("unmount Failure:operation failed")
        elif result == 401:
            ibmc.log_info("unmount Failure:session id is timeout or username and password is not correct!")
        else:
            ibmc.log_info('unmount Failure:unknown error ,error code is :%s' % result)
    except Exception as e:
        ibmc.log_error("unmount file exception is :%s" % str(e))
        raise e
    return result


def check_mount_task(ibmc, taskid):
    """
     Function:
          check mounting task if is finished
     Args:
          ibmc:  IbmcBaseConnect Object
          taskid:  id of mounting task
     Returns:
        ret {}
     Raises:
         Exception
     Examples:
         None
     Author:
     Date: 10/12/2020
    """
    # 等待20 秒mount超时
    task_timeout = 20
    token = ibmc.get_token()
    headers = {'content-type': 'application/json', 'X-Auth-Token': token}
    uri = "https://%s%s" % (ibmc.ip, taskid)
    payload = {}
    for _ in range(task_timeout):
        try:
            r = ibmc.request('GET', resource=uri,
                             headers=headers, data=payload, tmout=30)
        except Exception as e:
            ibmc.log_info(
                "get mount task exception; exception is: %s" % (str(e)))
        if r.json().get("EndTime"):
            if r.json().get("TaskStatus") == "OK":
                return True
            else:
                _error_msg = str(r.json().get("Messages"))
                ibmc.log_error(
                    "check mounting error message is %s" % (_error_msg))
                return False
        time.sleep(1)
    ibmc.log_error("check mounting task time out")
    return False


def mount_file(ibmc, os_img):
    """
     Function:
         mount file to virtual cd
     Args:
          ibmc:   IbmcBaseConnect Object
     Returns:
        ret {}
     Raises:
         Exception
     Examples:
         None
     Author:
     Date: 10/26/2019
    """
    token = ibmc.get_token()
    oem_info = ibmc.oem_info
    headers = {'content-type': 'application/json', 'X-Auth-Token': token}
    uri = "%s/VirtualMedia/CD/Oem/%s/Actions/VirtualMedia.VmmControl" % (ibmc.manager_uri, oem_info)
    payload = {'VmmControlType': 'Connect', 'Image': os_img}
    ret = False
    try:
        r = ibmc.request('POST', resource=uri,
                         headers=headers, data=payload, tmout=30)
        result = r.status_code
        if result == 202:
            _task_uri = r.json().get("@odata.id")
            ret = check_mount_task(ibmc, _task_uri)
        elif result == 404:
            ibmc.log_info("mount Failure:resource was not found")
        elif result == 400:
            ibmc.log_info("mount Failure:operation failed")
        elif result == 401:
            ibmc.log_info(
                "mount Failure:session id is timeout or username and password is not correct!")
        else:
            ibmc.log_info("mount Failure:unknown error")
    except Exception as e:
        ibmc.log_error("mount file exception ! exception is:%s" % str(e))
    return ret


def check_deploy_os_result(ibmc):
    """
    Function:
       check deploy os result
    Args:
        ibmc:   IbmcBaseConnect Object
    Returns:
      ret {}
    Raises:
       Exception
    Examples:
       None
    Author:
    Date: 10/26/2019
    """
    uri = "%s/SPService/SPResult/1" % ibmc.manager_uri
    token = ibmc.get_token()
    headers = {'content-type': 'application/json', 'X-Auth-Token': token}
    payload = {}
    rets = {
        SP_STATUS: 'Init', OS_PROGRESS: '',
        OS_STATUS: '', OS_STEP: '', OS_ERROR_INFO: ''
    }
    try:
        r = ibmc.request('GET', resource=uri, headers=headers,
                         data=payload, tmout=100)
        code = r.status_code
        if code == 200:
            r = r.json()
            sp_status = r[u'Status']
            rets[SP_STATUS] = sp_status
            ibmc.log_info("SP Status is %s" % sp_status)
            if sp_status == "Deploying" or sp_status == "Running" or sp_status == "Finished":
                rets[OS_PROGRESS] = r[OS_INSTALL][u'Progress']
                rets[OS_STATUS] = r[OS_INSTALL][RESULTS][0][u'Status']
                rets[OS_STEP] = r[OS_INSTALL][RESULTS][0][u'Step']
                rets[OS_ERROR_INFO] = r[OS_INSTALL][RESULTS][0][u'ErrorInfo']
        else:
            ibmc.log_error("get the sp result failed! error code is %s" % code)
    except Exception as e:
        ibmc.log_error("exception is thrown, get the sp result failed!%s" % str(e))
        rets = {
            SP_STATUS: 'Init', OS_PROGRESS: '',
            OS_STATUS: '', OS_STEP: '', OS_ERROR_INFO: ''
        }

    return rets


def safe_unmount(ibmc):
    """
    Safely unmount OS file.
    Only wrap the real risk point to satisfy try-minimal rule.
    """
    try:
        unmount_file(ibmc)
    except Exception as e:
        ibmc.log_error(
            "unmount OS file failed! exception error info:%s" % str(e)
        )


def precheck_and_prepare(ibmc, os_config):
    """
    Precheck versions and prepare SP environment.
    """
    # Check the BMC version
    r = ibmc.check_ibmc_version(BMC_EXPECT_VERSION)
    if r is False:
        rets = {}
        log_msg = "ibmc version must be %s or above" % BMC_EXPECT_VERSION
        set_result(ibmc.log_error, log_msg, False, rets)
        return rets

    # Check the SP version
    r = ibmc.check_sp_version(SP_EXPECT_VERSION)
    if r is False:
        rets = {}
        log_msg = "sp version must be %s or above" % SP_EXPECT_VERSION
        set_result(ibmc.log_error, log_msg, False, rets)
        return rets

    # get vmm is connected
    rets = vmm_is_connected(ibmc)
    ibmc.log_info("vmm connect stat is :" + str(rets))
    # if is connected,disconnect first
    if rets is True:
        ibmc.log_info("vmm is connected before, unmount!")
        safe_unmount(ibmc)
        time.sleep(CHECK_INTERVAL)

    # Power off the X86 system to make sure the SP is not running
    rets = manage_power(ibmc, "PowerOff")
    if rets.get(RESULT) is True:
        ibmc.log_info("Power off x86 System successfully!")
    else:
        log_msg = "Power off x86 System failed!"
        set_result(ibmc.log_error, log_msg, False, rets)
        return rets

    time.sleep(10)

    # Reset SP state ,Set SP Finished, in order to avoid the impact of last result
    rets = set_sp_finished(ibmc)
    if rets.get(RESULT) is False:
        log_msg = "set sp result finished failed! please try it again!"
        set_result(ibmc.log_error, log_msg, False, rets)
        return rets

    # parse ini file and get image config file
    rets = config_os(ibmc, os_config)
    if rets.get(RESULT) is False:
        manage_power(ibmc, "PowerOff")
        time.sleep(15)
        rets = config_os(ibmc, os_config)
        if rets.get(RESULT) is False:
            return rets

    return rets


def start_sp_and_mount_os(ibmc, os_img):
    """
    Enable SP service, mount OS image and start system.
    """
    # Set SP enabled
    rets = sp_api_set_sp_service(ibmc, sp_enable=True)
    if rets.get(RESULT) is True:
        ibmc.log_info("set sp_service  successfully!")
    else:
        time.sleep(CHECK_INTERVAL)
        rets = sp_api_set_sp_service(ibmc, sp_enable=True)
        if rets.get(RESULT) is True:
            ibmc.log_info("set sp service again successfully!")
        else:
            log_msg = "set sp service failed!"
            set_result(ibmc.log_error, log_msg, False, rets)
            return rets

    ## mount OS iso image
    r = mount_file(ibmc, os_img)
    if r is False:
        safe_unmount(ibmc)
        log_msg = "install OS failed! please check the OS image is exist or not!"
        set_result(ibmc.log_error, log_msg, False, rets)
        return rets

    # Start the X86 system to make the os config task available and install the OS.
    rets = manage_power(ibmc, "PowerOn")
    if rets.get(RESULT) is True:
        ibmc.log_info("power on the X86 system successfully!")
    else:
        safe_unmount(ibmc)
        log_msg = "install os failed! power on x86 System failed!"
        set_result(ibmc.log_error, log_msg, False, rets)
        return rets

    # wait sp start  30 min time out
    for cnt in range(WAIT_SP_START_TIME):
        ret = sp_api_get_status(ibmc)
        if SP_STATUS_WORKING == ret:
            return rets
        if cnt >= WAIT_SP_START_TIME - 1:
            safe_unmount(ibmc)
            log_msg = "deploy failed, wait sp start timeout"
            set_result(ibmc.log_error, log_msg, False, rets)
            return rets
        time.sleep(CHECK_INTERVAL)
    return rets


def wait_os_install_result(ibmc, rets):
    """
    Poll OS installation result.
    """
    loop_install = 0
    while 1:
        loop_install += 1

        try:
            status = check_deploy_os_result(ibmc)
        except Exception as e:
            log_msg = "install OS failed! exception error info:%s" % str(e)
            set_result(ibmc.log_error, log_msg, False, rets)
            safe_unmount(ibmc)
            return rets

        sp_status = status.get(u'sp_status')
        os_status = status.get(u'os_status')
        os_progress = status.get(u'os_progress')
        os_step = status.get(u'os_step')
        os_error_info = status.get(u'os_error_info')
        ibmc.log_info(
            "loopInstall:%s sp_status:%s, os_progress:%s, os_status:%s, "
            "os_step:%s, os_error_info:%s"
            % (loop_install, sp_status, os_progress, os_status, os_step, os_error_info)
        )

        if sp_status == "Init":
            ibmc.log_info("SP is initial, please wait!")
            time.sleep(60)
        elif sp_status == "Finished" and os_status == "Successful" and os_progress == "100":
            log_msg = "os install successfully"
            set_result(ibmc.log_info, log_msg, True, rets)
            safe_unmount(ibmc)
            return rets

        elif sp_status in ("Timeout", "Idle") or os_status == "Failed":
            log_msg = "os install failed, Error info is: %s" % os_error_info
            set_result(ibmc.log_error, log_msg, False, rets)
            safe_unmount(ibmc)
            return rets

        else:
            time.sleep(60)

        if loop_install >= 60:
            log_msg = "too many times loop, install OS has time out, please try it again!"
            set_result(ibmc.log_error, log_msg, False, rets)
            safe_unmount(ibmc)
            return rets


def deploy_os_by_sp_process(ibmc, os_img, os_config):
    """
    Function:
        deploy os by sp
    Args:
        ibmc: IbmcBaseConnect Object
        os_img (str): os image path
        os_config (dict): os config dict
    Returns:
        ret {}
    Raises:
        Exception
    Examples:
        None
    Author:
    Date: 10/26/2019
    """
    rets = precheck_and_prepare(ibmc, os_config)
    if rets.get(RESULT) is False:
        return rets

    rets = start_sp_and_mount_os(ibmc, os_img)
    if rets.get(RESULT) is False:
        return rets

    rets = wait_os_install_result(ibmc, rets)
    return rets
